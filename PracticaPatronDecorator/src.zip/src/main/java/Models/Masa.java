package main.java.Models;

public interface Masa {
    String getDescripcion();
    double getCosto();
}
